﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
    using test2.Models;

namespace UI
{
    public static class Actions { }
    public partial class Form_New_Destination : Form
    {

        public static event Action<Destination> DestinationSaveAction;
        Destination destination = new Destination();
        public Form_New_Destination()
        {
            InitializeComponent();
        }

        private void txtIPaddress_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            destination.Name = txtName.Text;
            destination.Ipaddress = txtIP.Text;
            switch (cmbPotocol.SelectedIndex)
            {
                case (0):
                    destination.Protocolid = 445;
                    destination.ProtocolType = "SMB";
                    break;
                case (1):
                    destination.Protocolid = 21;
                    destination.ProtocolType = "FTP";
                    break;
                case (2):
                    destination.Protocolid = 22;
                    destination.ProtocolType = "SFTP";
                    break;
                
            }
            destination.VirtualPath = txtVirPath.Text;
            destination.SrvUser = txtUser.Text;
            destination.SrvPassword = txtPassword.Text;

            DestinationSaveAction(destination);

        }

        private void txtVirPath_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
