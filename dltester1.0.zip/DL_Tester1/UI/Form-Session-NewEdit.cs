﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class Form_Session_NewEdit : Form
    {
        public Form_Session_NewEdit()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void mtxtNumTiming_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnDestEdit_Click(object sender, EventArgs e)
        {
           Form_Dest form_Dest= new Form_Dest();
            form_Dest.Show();
        }

        private void btnMonListEdit_Click(object sender, EventArgs e)
        {
            Form_MonListView form_MonListView = new Form_MonListView();
            form_MonListView.Show();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
