﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class Form1 : Form
    {
        UserCntr_EditSes userCntr_EditSes ;
        Form2 form2;
        public Form1()
        {


            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            Form_Session_NewEdit form_Session_NewEdit = new Form_Session_NewEdit();
            form_Session_NewEdit.Show();
          //  form2 = new Form2();
         //   form2.Show();
        }

        
    }
}
