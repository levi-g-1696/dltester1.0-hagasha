﻿
namespace UI
{
    partial class UserCntr_EditSes
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.ID = new System.Windows.Forms.Label();
            this.Expiration = new System.Windows.Forms.Label();
            this.Destination = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TimingBase = new System.Windows.Forms.Label();
            this.MonitorList = new System.Windows.Forms.Label();
            this.ValuesSched = new System.Windows.Forms.Label();
            this.OutputFilesType = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.Save = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Create New Session";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(19, 61);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(39, 15);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Name";
            // 
            // ID
            // 
            this.ID.AutoSize = true;
            this.ID.Location = new System.Drawing.Point(19, 99);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(18, 15);
            this.ID.TabIndex = 2;
            this.ID.Text = "ID";
            // 
            // Expiration
            // 
            this.Expiration.AutoSize = true;
            this.Expiration.Location = new System.Drawing.Point(19, 140);
            this.Expiration.Name = "Expiration";
            this.Expiration.Size = new System.Drawing.Size(114, 15);
            this.Expiration.TabIndex = 3;
            this.Expiration.Text = "Expiration after, min";
            // 
            // Destination
            // 
            this.Destination.AutoSize = true;
            this.Destination.Location = new System.Drawing.Point(19, 182);
            this.Destination.Name = "Destination";
            this.Destination.Size = new System.Drawing.Size(67, 15);
            this.Destination.TabIndex = 4;
            this.Destination.Text = "Destination";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 223);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Start Time";
            // 
            // TimingBase
            // 
            this.TimingBase.AutoSize = true;
            this.TimingBase.Location = new System.Drawing.Point(19, 269);
            this.TimingBase.Name = "TimingBase";
            this.TimingBase.Size = new System.Drawing.Size(68, 15);
            this.TimingBase.TabIndex = 6;
            this.TimingBase.Text = "TimingBase";
            // 
            // MonitorList
            // 
            this.MonitorList.AutoSize = true;
            this.MonitorList.Location = new System.Drawing.Point(19, 313);
            this.MonitorList.Name = "MonitorList";
            this.MonitorList.Size = new System.Drawing.Size(71, 15);
            this.MonitorList.TabIndex = 7;
            this.MonitorList.Text = "Monitor List";
            // 
            // ValuesSched
            // 
            this.ValuesSched.AutoSize = true;
            this.ValuesSched.Location = new System.Drawing.Point(19, 356);
            this.ValuesSched.Name = "ValuesSched";
            this.ValuesSched.Size = new System.Drawing.Size(102, 15);
            this.ValuesSched.TabIndex = 8;
            this.ValuesSched.Text = "Values Scheduling";
            // 
            // OutputFilesType
            // 
            this.OutputFilesType.AutoSize = true;
            this.OutputFilesType.Location = new System.Drawing.Point(19, 401);
            this.OutputFilesType.Name = "OutputFilesType";
            this.OutputFilesType.Size = new System.Drawing.Size(57, 15);
            this.OutputFilesType.TabIndex = 9;
            this.OutputFilesType.Text = "Files Type";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(168, 58);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(287, 23);
            this.textBox1.TabIndex = 10;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(168, 96);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(287, 23);
            this.textBox2.TabIndex = 11;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(168, 137);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(95, 23);
            this.comboBox1.TabIndex = 12;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(168, 179);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(233, 23);
            this.comboBox2.TabIndex = 13;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(168, 348);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(233, 23);
            this.comboBox3.TabIndex = 14;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(168, 305);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(233, 23);
            this.comboBox4.TabIndex = 15;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(168, 217);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 23);
            this.dateTimePicker1.TabIndex = 16;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(168, 261);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(95, 23);
            this.comboBox5.TabIndex = 17;
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(168, 398);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(95, 23);
            this.comboBox6.TabIndex = 18;
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(168, 455);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(75, 23);
            this.Save.TabIndex = 19;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(310, 455);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(75, 23);
            this.Cancel.TabIndex = 20;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            // 
            // UserCntr_EditSes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.comboBox6);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.OutputFilesType);
            this.Controls.Add(this.ValuesSched);
            this.Controls.Add(this.MonitorList);
            this.Controls.Add(this.TimingBase);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Destination);
            this.Controls.Add(this.Expiration);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.label1);
            this.Name = "UserCntr_EditSes";
            this.Size = new System.Drawing.Size(470, 500);
            this.Load += new System.EventHandler(this.UserCntr_EditSes_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label ID;
        private System.Windows.Forms.Label Expiration;
        private System.Windows.Forms.Label Destination;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label TimingBase;
        private System.Windows.Forms.Label MonitorList;
        private System.Windows.Forms.Label ValuesSched;
        private System.Windows.Forms.Label OutputFilesType;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Button Cancel;
    }
}
