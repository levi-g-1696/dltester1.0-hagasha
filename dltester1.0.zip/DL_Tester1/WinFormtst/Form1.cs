﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using test2.Models;

namespace WinFormtst
{
    public partial class Form1 : Form
    {
        public Form1()
        {

            


            InitializeComponent();
            BindGrid();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        //protected void Page_Load(object sender, EventArgs e)
        //{
        //    if (!this.IsPostBack)
        //    {
        //        this.BindGrid();
        //    }
        //}

        private void BindGrid()
        {
         //   using (CustomersEntities entities = new CustomersEntities())
  /*       using (DL_TesterContext db= new DL_TesterContext())
            {
                var aa = db.Destinations.Find(300);
                var bb = aa.DestinationId;
                //   dataGridView1.DataSource = aa;//
                // dataGridView1.DataSource = db.Destinations.ToList();
                dataGridView1.DataSource = (from dest in db.Destinations where dest.DestinationId < 304 
                                            select dest)
                    .ToList<Destination>();
             */
            }
        }

    }
