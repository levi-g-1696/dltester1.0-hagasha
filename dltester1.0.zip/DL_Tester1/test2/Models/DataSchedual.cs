﻿using System;
using System.Collections.Generic;

#nullable disable

namespace test2.Models
{
    public partial class DataSchedual
    {
        public int SchedId { get; set; }
        public int? SessionId { get; set; }
        public bool? IsSent { get; set; }
        public bool? WasErrorOnSending { get; set; }
        public int? RepeatCounter { get; set; }
        public DateTime? Time { get; set; }
        public double? Monitor1 { get; set; }
        public double? Monitor2 { get; set; }
        public double? Monitor3 { get; set; }
        public double? Monitor4 { get; set; }
        public double? Monitor5 { get; set; }
        public double? Monitor6 { get; set; }
        public double? Monitor7 { get; set; }
        public double? Monitor8 { get; set; }
        public double? Monitor9 { get; set; }
        public double? Monitor10 { get; set; }
        public double? Monitor11 { get; set; }
        public double? Monitor12 { get; set; }
        public double? Monitor13 { get; set; }
        public double? Monitor14 { get; set; }
        public double? Monitor15 { get; set; }
        public double? Monitor16 { get; set; }
    }
}
