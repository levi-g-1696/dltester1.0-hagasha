﻿using System;
using System.Net;
using System.Text.RegularExpressions;
using System.Linq;
//using test2.Models;
namespace test2
{
    public class A
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public A(int iD, string name)
        {
            ID = iD;
            Name = name;
        }
    }
    public class B
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public bool Enable { get; set; }

        public B(int iD, string name)
        {
            ID = iD;
            Name = name;
            Enable = true;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {

            //   using (DL_TesterContext db = new DL_TesterContext())
            {
                //     var aa = db.Destinations.Find(300);
                //     var bb = aa.DestinationId;
                //   dataGridView1.DataSource = (from ses in db.Sessions select ses).ToList();//
                A a = new A(45, "Cl-A");
                B b = new B(789, "cl---B");
               TestCopy.CopyPropertiesTo<B, A>(b, a);

            }

            //       =============== ipAddress ================





            //if (Regex.Match(w9ello, regx1).Success) { Console.WriteLine("Yes"); }

            //else Console.WriteLine("Hello not good");
            //if    (Regex.Match("w@43", regx2).Success) { Console.WriteLine("notnum"); } 
            //  if (Regex.Match("44.9", regx2).Success) { Console.WriteLine("44.9!"); }
            //==================================
            //    {
            //        Timer timer = new Timer();
            //        Console.WriteLine("   ######   hello   ####");
            //        Timer.CheckTimer.Func1();
            //        TimeAction.TimeActionRunner();
            //        for (int i = 0; i < 10; i++)
            //        {
            //            timer.RunTickEvents(5);
            //        }
            //    TimeAction.PrepareNextSending();

            //}
            //===================================
            //    public void Save(Destination dest)
            //{
            //  using (var dbct = new DL_TesterContext())

            //   using (var db = new DL_TesterContext())
            //{
            //  db.Destinations.Add(dest);
            // db.SaveChanges();
            // Console.WriteLine("dest saved");
        }



    }
    public static class TestCopy
    {
        public static void CopyPropertiesTo<T, TU>(this T source, TU dest)
        {
            var sourceProps = typeof(T).GetProperties().Where(x => x.CanRead).ToList();
            var destProps = typeof(TU).GetProperties()
                    .Where(x => x.CanWrite)
                    .ToList();

            foreach (var sourceProp in sourceProps)
            {
                if (destProps.Any(x => x.Name == sourceProp.Name))
                {
                    var p = destProps.First(x => x.Name == sourceProp.Name);
                    if (p.CanWrite)
                    { // check if the property can be set or no.
                        p.SetValue(dest, sourceProp.GetValue(source, null), null);
                    }
                }

            }
        }
        
    }

}



// }
//}
