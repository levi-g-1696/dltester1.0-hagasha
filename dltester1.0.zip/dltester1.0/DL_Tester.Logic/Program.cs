﻿using System;
using test2.Models;
using 
namespace DL_Tester.Logic
{
    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
