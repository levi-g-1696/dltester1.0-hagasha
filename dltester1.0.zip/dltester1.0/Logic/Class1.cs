﻿using System;
using UI;
namespace Logic
{
    public class Class1
    {
    }
}
