﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using test2;

namespace Manage
{
   public enum LoginResult {OK,
    UserPswWrong,
    UserAccountExpired}
    public static class Methods
    {
       

       
        public static void CopyPropertiesTo<T, TU>(this T source, TU dest)
        {//this solution was token from "stackoverflow" portal

            var sourceProps = typeof(T).GetProperties().Where(x => x.CanRead).ToList();
            var destProps = typeof(TU).GetProperties()
                    .Where(x => x.CanWrite)
                    .ToList();

            foreach (var sourceProp in sourceProps)
            {




                if (destProps.Any(x => x.Name == sourceProp.Name))
                {
                    var p = destProps.First(x => x.Name == sourceProp.Name);
                    if ((p.CanWrite) && (sourceProp.GetValue(source, null) != null))
                    { // check if the property can be set or no.
                        p.SetValue(dest, sourceProp.GetValue(source, null), null);
                    }
                }

            }

        }
        public static LoginResult CheckLogin(string user, string psw)
        {
           
            var userOnDB = DBconnection.FindUser(user);
            if (userOnDB == null) return LoginResult.UserPswWrong;
            else if (userOnDB.Password != psw) return LoginResult.UserPswWrong;
            else if (userOnDB.ExpirationDate.Value < DateTime.Now) return LoginResult.UserAccountExpired;
            else { 
                return LoginResult.OK; }
           
        }
    }
}
