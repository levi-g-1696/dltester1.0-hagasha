﻿
namespace UI
{
    partial class Form_MonList_NewEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtMon16 = new System.Windows.Forms.TextBox();
            this.txtMon15 = new System.Windows.Forms.TextBox();
            this.txtMon14 = new System.Windows.Forms.TextBox();
            this.txtMon13 = new System.Windows.Forms.TextBox();
            this.txtMon12 = new System.Windows.Forms.TextBox();
            this.txtMon11 = new System.Windows.Forms.TextBox();
            this.txtMon10 = new System.Windows.Forms.TextBox();
            this.txtMon9 = new System.Windows.Forms.TextBox();
            this.lblMon16 = new System.Windows.Forms.Label();
            this.lblMon15 = new System.Windows.Forms.Label();
            this.lblMon14 = new System.Windows.Forms.Label();
            this.lblMon13 = new System.Windows.Forms.Label();
            this.lblMon12 = new System.Windows.Forms.Label();
            this.lblMon11 = new System.Windows.Forms.Label();
            this.lblMon10 = new System.Windows.Forms.Label();
            this.lblMon9 = new System.Windows.Forms.Label();
            this.cmbNumber = new System.Windows.Forms.ComboBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtMon8 = new System.Windows.Forms.TextBox();
            this.txtMon7 = new System.Windows.Forms.TextBox();
            this.txtMon6 = new System.Windows.Forms.TextBox();
            this.txtMon5 = new System.Windows.Forms.TextBox();
            this.txtMon4 = new System.Windows.Forms.TextBox();
            this.txtMon3 = new System.Windows.Forms.TextBox();
            this.txtMon2 = new System.Windows.Forms.TextBox();
            this.txtMon1 = new System.Windows.Forms.TextBox();
            this.lblMon8 = new System.Windows.Forms.Label();
            this.lblMon7 = new System.Windows.Forms.Label();
            this.lblMon6 = new System.Windows.Forms.Label();
            this.lblMon5 = new System.Windows.Forms.Label();
            this.lblMon4 = new System.Windows.Forms.Label();
            this.lblMon3 = new System.Windows.Forms.Label();
            this.lblMon2 = new System.Windows.Forms.Label();
            this.lblMon1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblPanelName = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.txtMon16);
            this.panel1.Controls.Add(this.txtMon15);
            this.panel1.Controls.Add(this.txtMon14);
            this.panel1.Controls.Add(this.txtMon13);
            this.panel1.Controls.Add(this.txtMon12);
            this.panel1.Controls.Add(this.txtMon11);
            this.panel1.Controls.Add(this.txtMon10);
            this.panel1.Controls.Add(this.txtMon9);
            this.panel1.Controls.Add(this.lblMon16);
            this.panel1.Controls.Add(this.lblMon15);
            this.panel1.Controls.Add(this.lblMon14);
            this.panel1.Controls.Add(this.lblMon13);
            this.panel1.Controls.Add(this.lblMon12);
            this.panel1.Controls.Add(this.lblMon11);
            this.panel1.Controls.Add(this.lblMon10);
            this.panel1.Controls.Add(this.lblMon9);
            this.panel1.Controls.Add(this.cmbNumber);
            this.panel1.Controls.Add(this.txtName);
            this.panel1.Controls.Add(this.txtMon8);
            this.panel1.Controls.Add(this.txtMon7);
            this.panel1.Controls.Add(this.txtMon6);
            this.panel1.Controls.Add(this.txtMon5);
            this.panel1.Controls.Add(this.txtMon4);
            this.panel1.Controls.Add(this.txtMon3);
            this.panel1.Controls.Add(this.txtMon2);
            this.panel1.Controls.Add(this.txtMon1);
            this.panel1.Controls.Add(this.lblMon8);
            this.panel1.Controls.Add(this.lblMon7);
            this.panel1.Controls.Add(this.lblMon6);
            this.panel1.Controls.Add(this.lblMon5);
            this.panel1.Controls.Add(this.lblMon4);
            this.panel1.Controls.Add(this.lblMon3);
            this.panel1.Controls.Add(this.lblMon2);
            this.panel1.Controls.Add(this.lblMon1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.lblName);
            this.panel1.Controls.Add(this.lblPanelName);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(403, 517);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(253, 473);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 23);
            this.btnCancel.TabIndex = 42;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(69, 473);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 23);
            this.btnSave.TabIndex = 41;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtMon16
            // 
            this.txtMon16.Location = new System.Drawing.Point(252, 423);
            this.txtMon16.Name = "txtMon16";
            this.txtMon16.Size = new System.Drawing.Size(112, 23);
            this.txtMon16.TabIndex = 40;
            // 
            // txtMon15
            // 
            this.txtMon15.Location = new System.Drawing.Point(252, 384);
            this.txtMon15.Name = "txtMon15";
            this.txtMon15.Size = new System.Drawing.Size(112, 23);
            this.txtMon15.TabIndex = 39;
            // 
            // txtMon14
            // 
            this.txtMon14.Location = new System.Drawing.Point(253, 344);
            this.txtMon14.Name = "txtMon14";
            this.txtMon14.Size = new System.Drawing.Size(112, 23);
            this.txtMon14.TabIndex = 38;
            // 
            // txtMon13
            // 
            this.txtMon13.Location = new System.Drawing.Point(253, 299);
            this.txtMon13.Name = "txtMon13";
            this.txtMon13.Size = new System.Drawing.Size(112, 23);
            this.txtMon13.TabIndex = 37;
            // 
            // txtMon12
            // 
            this.txtMon12.Location = new System.Drawing.Point(252, 255);
            this.txtMon12.Name = "txtMon12";
            this.txtMon12.Size = new System.Drawing.Size(112, 23);
            this.txtMon12.TabIndex = 36;
            // 
            // txtMon11
            // 
            this.txtMon11.Location = new System.Drawing.Point(253, 210);
            this.txtMon11.Name = "txtMon11";
            this.txtMon11.Size = new System.Drawing.Size(112, 23);
            this.txtMon11.TabIndex = 35;
            // 
            // txtMon10
            // 
            this.txtMon10.Location = new System.Drawing.Point(252, 167);
            this.txtMon10.Name = "txtMon10";
            this.txtMon10.Size = new System.Drawing.Size(112, 23);
            this.txtMon10.TabIndex = 34;
            // 
            // txtMon9
            // 
            this.txtMon9.Location = new System.Drawing.Point(252, 128);
            this.txtMon9.Name = "txtMon9";
            this.txtMon9.Size = new System.Drawing.Size(112, 23);
            this.txtMon9.TabIndex = 33;
            // 
            // lblMon16
            // 
            this.lblMon16.AutoSize = true;
            this.lblMon16.Location = new System.Drawing.Point(209, 426);
            this.lblMon16.Name = "lblMon16";
            this.lblMon16.Size = new System.Drawing.Size(44, 15);
            this.lblMon16.TabIndex = 32;
            this.lblMon16.Text = "mon16";
            // 
            // lblMon15
            // 
            this.lblMon15.AutoSize = true;
            this.lblMon15.Location = new System.Drawing.Point(209, 387);
            this.lblMon15.Name = "lblMon15";
            this.lblMon15.Size = new System.Drawing.Size(44, 15);
            this.lblMon15.TabIndex = 31;
            this.lblMon15.Text = "mon15";
            // 
            // lblMon14
            // 
            this.lblMon14.AutoSize = true;
            this.lblMon14.Location = new System.Drawing.Point(209, 347);
            this.lblMon14.Name = "lblMon14";
            this.lblMon14.Size = new System.Drawing.Size(44, 15);
            this.lblMon14.TabIndex = 30;
            this.lblMon14.Text = "mon14";
            // 
            // lblMon13
            // 
            this.lblMon13.AutoSize = true;
            this.lblMon13.Location = new System.Drawing.Point(209, 302);
            this.lblMon13.Name = "lblMon13";
            this.lblMon13.Size = new System.Drawing.Size(44, 15);
            this.lblMon13.TabIndex = 29;
            this.lblMon13.Text = "mon13";
            // 
            // lblMon12
            // 
            this.lblMon12.AutoSize = true;
            this.lblMon12.Location = new System.Drawing.Point(209, 258);
            this.lblMon12.Name = "lblMon12";
            this.lblMon12.Size = new System.Drawing.Size(44, 15);
            this.lblMon12.TabIndex = 28;
            this.lblMon12.Text = "mon12";
            // 
            // lblMon11
            // 
            this.lblMon11.AutoSize = true;
            this.lblMon11.Location = new System.Drawing.Point(209, 213);
            this.lblMon11.Name = "lblMon11";
            this.lblMon11.Size = new System.Drawing.Size(44, 15);
            this.lblMon11.TabIndex = 27;
            this.lblMon11.Text = "mon11";
            // 
            // lblMon10
            // 
            this.lblMon10.AutoSize = true;
            this.lblMon10.Location = new System.Drawing.Point(208, 170);
            this.lblMon10.Name = "lblMon10";
            this.lblMon10.Size = new System.Drawing.Size(44, 15);
            this.lblMon10.TabIndex = 26;
            this.lblMon10.Text = "mon10";
            // 
            // lblMon9
            // 
            this.lblMon9.AutoSize = true;
            this.lblMon9.Location = new System.Drawing.Point(208, 131);
            this.lblMon9.Name = "lblMon9";
            this.lblMon9.Size = new System.Drawing.Size(38, 15);
            this.lblMon9.TabIndex = 25;
            this.lblMon9.Text = "mon9";
            // 
            // cmbNumber
            // 
            this.cmbNumber.FormattingEnabled = true;
            this.cmbNumber.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "15",
            "15",
            "16"});
            this.cmbNumber.Location = new System.Drawing.Point(134, 89);
            this.cmbNumber.Name = "cmbNumber";
            this.cmbNumber.Size = new System.Drawing.Size(35, 23);
            this.cmbNumber.TabIndex = 24;
            this.cmbNumber.SelectedIndexChanged += new System.EventHandler(this.cmbNumber_SelectedIndexChanged);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(58, 52);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(169, 23);
            this.txtName.TabIndex = 23;
            this.txtName.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // txtMon8
            // 
            this.txtMon8.Location = new System.Drawing.Point(57, 423);
            this.txtMon8.Name = "txtMon8";
            this.txtMon8.Size = new System.Drawing.Size(112, 23);
            this.txtMon8.TabIndex = 22;
            // 
            // txtMon7
            // 
            this.txtMon7.Location = new System.Drawing.Point(57, 384);
            this.txtMon7.Name = "txtMon7";
            this.txtMon7.Size = new System.Drawing.Size(112, 23);
            this.txtMon7.TabIndex = 21;
            // 
            // txtMon6
            // 
            this.txtMon6.Location = new System.Drawing.Point(58, 344);
            this.txtMon6.Name = "txtMon6";
            this.txtMon6.Size = new System.Drawing.Size(112, 23);
            this.txtMon6.TabIndex = 20;
            // 
            // txtMon5
            // 
            this.txtMon5.Location = new System.Drawing.Point(58, 299);
            this.txtMon5.Name = "txtMon5";
            this.txtMon5.Size = new System.Drawing.Size(112, 23);
            this.txtMon5.TabIndex = 19;
            // 
            // txtMon4
            // 
            this.txtMon4.Location = new System.Drawing.Point(57, 255);
            this.txtMon4.Name = "txtMon4";
            this.txtMon4.Size = new System.Drawing.Size(112, 23);
            this.txtMon4.TabIndex = 18;
            // 
            // txtMon3
            // 
            this.txtMon3.Location = new System.Drawing.Point(58, 210);
            this.txtMon3.Name = "txtMon3";
            this.txtMon3.Size = new System.Drawing.Size(112, 23);
            this.txtMon3.TabIndex = 17;
            this.txtMon3.TextChanged += new System.EventHandler(this.txtMon3_TextChanged_1);
            // 
            // txtMon2
            // 
            this.txtMon2.Location = new System.Drawing.Point(57, 167);
            this.txtMon2.Name = "txtMon2";
            this.txtMon2.Size = new System.Drawing.Size(112, 23);
            this.txtMon2.TabIndex = 16;
            // 
            // txtMon1
            // 
            this.txtMon1.Location = new System.Drawing.Point(57, 128);
            this.txtMon1.Name = "txtMon1";
            this.txtMon1.Size = new System.Drawing.Size(112, 23);
            this.txtMon1.TabIndex = 15;
            // 
            // lblMon8
            // 
            this.lblMon8.AutoSize = true;
            this.lblMon8.Location = new System.Drawing.Point(14, 426);
            this.lblMon8.Name = "lblMon8";
            this.lblMon8.Size = new System.Drawing.Size(38, 15);
            this.lblMon8.TabIndex = 14;
            this.lblMon8.Text = "mon8";
            // 
            // lblMon7
            // 
            this.lblMon7.AutoSize = true;
            this.lblMon7.Location = new System.Drawing.Point(14, 387);
            this.lblMon7.Name = "lblMon7";
            this.lblMon7.Size = new System.Drawing.Size(38, 15);
            this.lblMon7.TabIndex = 13;
            this.lblMon7.Text = "mon7";
            // 
            // lblMon6
            // 
            this.lblMon6.AutoSize = true;
            this.lblMon6.Location = new System.Drawing.Point(14, 347);
            this.lblMon6.Name = "lblMon6";
            this.lblMon6.Size = new System.Drawing.Size(38, 15);
            this.lblMon6.TabIndex = 12;
            this.lblMon6.Text = "mon6";
            // 
            // lblMon5
            // 
            this.lblMon5.AutoSize = true;
            this.lblMon5.Location = new System.Drawing.Point(14, 302);
            this.lblMon5.Name = "lblMon5";
            this.lblMon5.Size = new System.Drawing.Size(38, 15);
            this.lblMon5.TabIndex = 11;
            this.lblMon5.Text = "mon5";
            // 
            // lblMon4
            // 
            this.lblMon4.AutoSize = true;
            this.lblMon4.Location = new System.Drawing.Point(14, 258);
            this.lblMon4.Name = "lblMon4";
            this.lblMon4.Size = new System.Drawing.Size(38, 15);
            this.lblMon4.TabIndex = 10;
            this.lblMon4.Text = "mon4";
            // 
            // lblMon3
            // 
            this.lblMon3.AutoSize = true;
            this.lblMon3.Location = new System.Drawing.Point(14, 213);
            this.lblMon3.Name = "lblMon3";
            this.lblMon3.Size = new System.Drawing.Size(38, 15);
            this.lblMon3.TabIndex = 5;
            this.lblMon3.Text = "mon3";
            this.lblMon3.Click += new System.EventHandler(this.lblMon3_Click);
            // 
            // lblMon2
            // 
            this.lblMon2.AutoSize = true;
            this.lblMon2.Location = new System.Drawing.Point(13, 170);
            this.lblMon2.Name = "lblMon2";
            this.lblMon2.Size = new System.Drawing.Size(38, 15);
            this.lblMon2.TabIndex = 4;
            this.lblMon2.Text = "mon2";
            // 
            // lblMon1
            // 
            this.lblMon1.AutoSize = true;
            this.lblMon1.Location = new System.Drawing.Point(13, 131);
            this.lblMon1.Name = "lblMon1";
            this.lblMon1.Size = new System.Drawing.Size(38, 15);
            this.lblMon1.TabIndex = 3;
            this.lblMon1.Text = "mon1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Number of  monitors";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(13, 55);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(39, 15);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Name";
            // 
            // lblPanelName
            // 
            this.lblPanelName.AutoSize = true;
            this.lblPanelName.Location = new System.Drawing.Point(13, 13);
            this.lblPanelName.Name = "lblPanelName";
            this.lblPanelName.Size = new System.Drawing.Size(135, 15);
            this.lblPanelName.TabIndex = 0;
            this.lblPanelName.Text = "Create New Monitor List";
            // 
            // Form_MonList_NewEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 517);
            this.Controls.Add(this.panel1);
            this.Name = "Form_MonList_NewEdit";
            this.Text = "Form_MonList_NewEdit";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblMon8;
        private System.Windows.Forms.Label lblMon7;
        private System.Windows.Forms.Label lblMon6;
        private System.Windows.Forms.Label lblMon5;
        private System.Windows.Forms.Label lblMon4;
        private System.Windows.Forms.Label lblMon3;
        private System.Windows.Forms.Label lblMon2;
        private System.Windows.Forms.Label lblMon1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblPanelName;
        private System.Windows.Forms.TextBox txtMon8;
        private System.Windows.Forms.TextBox txtMon7;
        private System.Windows.Forms.TextBox txtMon6;
        private System.Windows.Forms.TextBox txtMon5;
        private System.Windows.Forms.TextBox txtMon4;
        private System.Windows.Forms.TextBox txtMon3;
        private System.Windows.Forms.TextBox txtMon2;
        private System.Windows.Forms.TextBox txtMon1;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtMon16;
        private System.Windows.Forms.TextBox txtMon15;
        private System.Windows.Forms.TextBox txtMon14;
        private System.Windows.Forms.TextBox txtMon13;
        private System.Windows.Forms.TextBox txtMon12;
        private System.Windows.Forms.TextBox txtMon11;
        private System.Windows.Forms.TextBox txtMon10;
        private System.Windows.Forms.TextBox txtMon9;
        private System.Windows.Forms.Label lblMon16;
        private System.Windows.Forms.Label lblMon15;
        private System.Windows.Forms.Label lblMon14;
        private System.Windows.Forms.Label lblMon13;
        private System.Windows.Forms.Label lblMon12;
        private System.Windows.Forms.Label lblMon11;
        private System.Windows.Forms.Label lblMon10;
        private System.Windows.Forms.Label lblMon9;
        private System.Windows.Forms.ComboBox cmbNumber;
        private System.Windows.Forms.TextBox txtName;
    }
}