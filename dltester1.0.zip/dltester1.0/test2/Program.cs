﻿using System;
//using test2.Models;
namespace test2
{
    public enum Editmode { New, Edit }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello test2 running");


       
            {
                Timer timer = new Timer();
                Console.WriteLine("   ######   hello   ####");
               Timer. CheckTimer.Func1();
                TimeAction.TimeActionRunner();
                for (int i = 0; i < 10; i++)
                {
                    timer.RunTickEvents(5);
                }





            }
            TimeAction.PrepareNextSending();
            
        }
     /*   public void Save(Destination dest)
        {
          //  using (var dbct = new DL_TesterContext())
               
            using (var db = new DL_TesterContext())
            {
                db.Destinations.Add(dest);
                db.SaveChanges();
                Console.WriteLine("dest saved");
            }
        } */
    }
}
