﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Timers;
using System.Text;
using System.Threading.Tasks;

using test2.Models;

namespace test2
{
    class TimeAction
    {
        public static bool schedContinueFlag { get; set; } = true;
        public static void PrepareNextSending()
        {
            //   Console.WriteLine("PREP");
            var timeNow = DateTime.Now;
            List<DataSchedual> tasklist;
            List<int?> fileTypesUsed;
            List<int?> fileTypesListToSend = new List<int?>();
            List<string> monitorNamesToSend = new List<string>();
            List<Destination> destinationsToSend = new List<Destination>();
         
            List<string> files = new List<string>();
            using (var dbct = new DL_TesterContext())
            {

                tasklist = dbct.DataScheduals.Where(ds => ds.Time < timeNow).Where(ds => ds.IsSent == false || ds.WasErrorOnSending == true).ToList();
                var idlist = from t in tasklist select t.SessionId;

                var qur = dbct.Sessions.Where(s => idlist.Contains(s.SessionId));
                fileTypesUsed = (from q in qur select q.OutputTypeId).ToList();
                var listOfMonitorList = (from q in qur select q.MonitorList).ToList();
                var destinationList = (from q in qur select q.Destination).ToList();

                /*    loop for all tasks time < curent && notsent || was error
                 *      make list for send mashine
                 *      make files for sendmachine
                 *      make event fot smashine
                 *      set issent=1
                 *    
                 *    
                 *    
                 */
                //   var tsk = tasklist

                // ************make file type list
                foreach (var task in tasklist)
                {
                    int idsession = (int)task.SessionId;
                    var fileType = from q in qur where (q.SessionId == idsession) select q.OutputTypeId;
                    var monitors = from q in qur where (q.SessionId == idsession) select q.MonitorList.MonitorNames;
                    var dest = from q in qur where (q.SessionId == idsession) select q.Destination;
                    fileTypesListToSend.Add(fileType.FirstOrDefault());
                    monitorNamesToSend.Add(monitors.FirstOrDefault());
                    destinationsToSend.Add(dest.FirstOrDefault());

                }
                //**************  make files and list of them for sending***************************

                if (tasklist.Count != fileTypesListToSend.Count) throw new Exception("Count of tasks filetypes lists is not eqil :ex001");
                for (int i = 0; i < tasklist.Count; i++)
                {

                    files.Add(MakeFileForSend(tasklist[i], (int)fileTypesListToSend[i], monitorNamesToSend[i]));

                }

                SendMachine(files, destinationsToSend);
            }



        }
        public static string MakeFileForSend(DataSchedual task, int fileType, string monitorNames)
        {
            string filepath = "";


            if (fileType == 1) filepath = "C:\\Users\\user22\\Desktop\\KURS DOCS\\1project meadleway\\test\\test\\files\\test1.csv";
            else if (fileType == 2) filepath = "C:\\Users\\user22\\Desktop\\KURS DOCS\\1project meadleway\\test\\test\\files\\test1.json";

            return filepath;
        }
        public static void SendMachine(List<string> fileList, List<Destination> destinations)
        {
            if (fileList.Count != destinations.Count) throw new Exception("Count of  files and destinations lists is not eqil :ex002");
            Console.WriteLine(" ####   sendmachine  ########");
            Console.WriteLine(" ... checking if files  are existing");
            Console.WriteLine(" ... sendind the files ");
            for (int i = 0; i < fileList.Count; i++)
            {
                string sendinfo = "" + fileList[i] + "sending to  " + destinations[i].Ipaddress + " protocolID:" + destinations[i].Protocolid;
                Console.WriteLine(sendinfo);
            }
            Console.WriteLine(" ####   sendmachine finished to send  ######## ");
        }

        public static void TimeActionRunner()
        {

            {
                Timer.TickEvent += PrepareNextSending;

            }




        }


    }


}

